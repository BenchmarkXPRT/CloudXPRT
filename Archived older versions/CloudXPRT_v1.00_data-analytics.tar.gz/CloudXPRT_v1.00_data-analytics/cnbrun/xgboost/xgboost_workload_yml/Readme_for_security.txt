kubectl create clusterrolebinding default-admin --clusterrole cluster-admin --serviceaccount=kafka:default
