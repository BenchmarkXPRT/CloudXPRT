prefix = "default"
zone   = "hel1"

inventory_file = "inventory.ini"

ssh_public_keys = [
  # Put your public SSH key here
  "ssh-rsa I-did-not-read-the-docs",
  "ssh-rsa I-did-not-read-the-docs 2",
]

machines = {
  "master-0" : {
    "node_type" : "master",
    "size" : "cx21",
    "image" : "ubuntu-20.04",
  },
  "worker-0" : {
    "node_type" : "worker",
    "size" : "cx21",
    "image" : "ubuntu-20.04",
  },
  "worker-1" : {
    "node_type" : "worker",
    "size" : "cx21",
    "image" : "ubuntu-20.04",
  }
}

nodeport_whitelist = [
  "0.0.0.0/0"
]

ingress_whitelist = [
  "0.0.0.0/0"
]

ssh_whitelist = [
  "0.0.0.0/0"
]

api_server_whitelist = [
  "0.0.0.0/0"
]
